﻿namespace ProgramThatSavesItsStatus
{
    public enum SaveType
    {
        XML,
        TXT,
        Binary,
        Register
    }
}
